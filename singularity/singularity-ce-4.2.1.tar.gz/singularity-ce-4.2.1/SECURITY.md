# Security Policy

SingularityCE follows the Sylabs Security Policy available at:

<https://sylabs.io/security-policy/>

## Reporting a Vulnerability

If you have found a vulnerability in SingularityCE, please review the policy
linked above and then contact <security@sylabs.io>

PGP encrypted email is accepted, with key details at the link above.
